console.log('D S P    3');

let ph=0,f=.1;

import value from './value.js';
let maxa=.1;
var x=0, y=0, vx=0, vy=0, ax=0, ay=0, targetx=0, targety=0, v=0;

const BUFFERDIM = 128*1024;
const UNDERSAMPLE = 64;

let cfg = {
	maxa: 0.0003,
	mina: 0.000001,
	minv: 0.00000001,
	dump: .1,
	vfilt: .3
};

let x_array = new Float32Array(BUFFERDIM);
let y_array = new Float32Array(BUFFERDIM);
let vx_array = new Float32Array(BUFFERDIM);
let vy_array = new Float32Array(BUFFERDIM);
let v_array = new Float32Array(BUFFERDIM);
let insertPointCursor = 0;
let lastRead = 0;
let usx=0,usvx=0,usy=0,usvy=0;
let us_count=0;
let vmod,vmodmax=0;
class MyCustomProcessor extends AudioWorkletProcessor {
	
	constructor(...args) {
        super(...args)
        
		console.log('sr '+sampleRate);
		let outfun = x=>this.port.postMessage(x);

        this.port.onmessage = (e) => {
            //console.log('received '+e.data);
            onDataInput(e.data, outfun);
        }
    }

    process(inputs, outputs, parameters) {

		function undersampleControl() {
			xy_step();
			usvx=(x-usx)/UNDERSAMPLE;
			usvy=(y-usy)/UNDERSAMPLE;
		}

		function __xy_step() {
			x+=(targetx-x)*.05;
			y+=(targety-y)*.05;
		}
		function xy_step() {
			vx -= vx*cfg.dump;
			vy -= vy*cfg.dump;
			
			let dx = targetx-x;
			let dy = targety-y;
			ax = dx-vx;
			ay = dy-vy;
			let m = Math.sqrt(ax*ax+ay*ay);
			
			if (m>cfg.maxa) {
				let fact = cfg.maxa/m;
				ax *= fact;
				ay *= fact; 
			}
			else if (m<cfg.mina) {
				ax = ay = 0;
			}
	
			let av = common.value(x, y);
			v += (av-v)*cfg.vfilt;
			
			insertPoint(x,y,vx,vy,v);
			vmod = Math.sqrt(vx*vx+vy*vy);
			if (vmod>cfg.minv) {
				x += vx;
				y += vy;	
				if (vmod>vmodmax)
					console.log('vmod='+(vmodmax=vmod));
			}
			vx += ax;
			vy += ay;
	
		}
	
	
        const output = outputs[0];
    	//showInfo({inputs, outputs, parameters, l:output[0]});
		let len = output[0].length;
		for (let sample=0; sample<len; sample++) {
			if (us_count%UNDERSAMPLE==0) 
				undersampleControl();

			us_count++;

			let av = common.value(usx, usy);
			v += (av-v)*cfg.vfilt;

			usx += usvx;
			usy += usvy;
						

			let signal = Math.sin(ph);		
			ph += f*(1+v*.05);

			for(let ch=0;ch<output.length; ch++)
				output[ch][sample] = signal;
        }
        return true
    }
}

function onDataInput(msg, outfun) {
	if (msg.charAt(0)=='{') {
		let obj = JSON.parse(msg);
		if (obj.cfg) {
			console.log({cfg});
			cfg = obj.cfg;
			console.log({cfg});
		}
		if (obj.x) {
			targetx=obj.x;
		}
		if (obj.y) {
			targety=obj.y;
		}
	}

	if (msg.indexOf('telemetry')==0) {
		telemetry(outfun);
	}
	// if (msg.indexOf('telemetry')==0) {
	// 	let n = msg.split(' ')[1]-0;
	// 	console.log('telemetry n='+n);
	// 	telemetry(n, outfun);
	// }
	if (msg.indexOf('status')==0) {
		outfun(JSON.stringify({
			status:{
				x, y, vx, vy, ax, ay, targetx, targety
			}
		},null,2));
	}

}

function telemetry(outfun) {
	try{
		let lastWrite = (insertPointCursor-1) % BUFFERDIM;
		let acc=['tele'];
		while(lastRead!=lastWrite) {
			let p = lastRead;
			lastRead = (lastRead+1) % BUFFERDIM;
			let a = [
				x_array[p],
				y_array[p],
				vx_array[p],
				vy_array[p],
				v_array[p] 
			];
			acc.push(a.map(x=>x.toString()).join(','));
		}
		let msg = acc.join('\n');
		outfun(msg);
	}
	catch(e) {
		console.log(e);
	}
}

// function telemetry(n, outfun) {
// 	try{
// 		let last = (insertPointCursor-1) % BUFFERDIM;
// 		let first = (last-n) % BUFFERDIM;
// 		let acc=['tele'];
// 		for(let i=0, p=first; i<n; i++) {
// 			let a = [
// 				x_array[p],
// 				y_array[p],
// 				vx_array[p],
// 				vy_array[p],
// 				v_array[p] 
// 			];
// 			acc.push(a.map(x=>x.toString()).join(','));
// 			p++;
// 			if (p>=BUFFERDIM) p=0;
// 		}
// 		let msg = acc.join('\n');
// 		outfun(msg);

// 	}
// 	catch(e) {
// 		console.log(e);
// 	}
// }

function insertPoint(x,y,vx,vy,v) {
	x_array[insertPointCursor] = x;
	y_array[insertPointCursor] = y;
	vx_array[insertPointCursor] = vx;
	vy_array[insertPointCursor] = vy;
	v_array[insertPointCursor] = v;
	
	insertPointCursor = (insertPointCursor+1) % BUFFERDIM;
}

registerProcessor('my-custom-dsp', MyCustomProcessor);



//let last_ts = new Date().getTime();

// function insertpoint(x,y) {
// 	let v = common.value(x,y);
// }

// function setxy(newx,newy, timestamp) {
// 	let dt=timestamp-last_ts;
// 	// assumo che target = src + v0*dt + a*dt*(dt-1)/2
// 	// => a*dt*(dt-1)/2 = target-src-v0*dt
// 	// => a*dt*(dt-1) = 2*(target-src-v0*dt)
// 	// => a = 2*(target-src-v0*dt)/(dt*(dt-1))

// 	let ax = 2*(newx-x-vx*dt)/(dt*(dt-1));
// 	let ay = 2*(newy-y-vy*dt)/(dt*(dt-1));

// 	let ma=Math.sqrt(ax*ax+ay*ay);
// 	if (ma>maxa) {
// 		let fact = maxa/ma;
// 		ax /=fact;
// 		ay /= fact;
// 	}
// 	// for(let i=0;i<dt;i++) {
// 	// 	x += vx;
// 	// 	y += vy;
// 	// 	vx += ax;
// 	// 	vy += ay;
// 	// 	insertpoint(x,y);
// 	// }
// } 

function showInfo(val) {
	if (showInfo.done)
		return;
	showInfo.done=true;
	console.log(val);
};